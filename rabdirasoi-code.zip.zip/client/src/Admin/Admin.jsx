import React from 'react'
import "./Admin.css"
import AdminSidebar from './components/AdminSidebar/AdminSidebar'

const Admin = () => {
  return (
    <div className="admin-container">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, minima quasi molestias labore deleniti, velit ullam maiores, unde corrupti totam dolores fugiat praesentium vero exercitationem deserunt impedit. Enim, cupiditate est.
    </div>
  )
}

export default Admin