export default function Socials({ icon }) {
  return (
    <div className="socials">
      {icon}
    </div>
  );
}