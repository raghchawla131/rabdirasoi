import "./About.css"

export default function About() {
  return (
    <div className="about-us">
      <div>
        <div></div>
        <div></div>
      </div>
      <div></div>
    </div>
  );
}
